﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static Revisao.Fat;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Revisao
{
    public class Fat
    {
        public class Fatorial()
        {
            public int CalculoFatorial(int num1)
            {
                int i, numero, fatorial;
                numero = num1;
                fatorial = num1;
                for (i = numero - 1; i >= 1; i--)
                {
                    fatorial = fatorial * i;
                }
                return fatorial;
            }
        }

        public class Fibonacci()
        {
            public int CalculoFibonacci(int posicao)
            {
                int a = 0;
                int b = 1;

                while (b <= posicao)
                {
                    int prox = a + b;
                    a = b;
                    b = prox;
                }
                return b;
            }
        }

        public static class Baskara
        {
            public static int[] CalculoRaiz1(int num4, int num5, int num6)
            {
               double delta = 0;
               double a1 = 0;
               double a2 = 0;

                delta = (num5 * num5) - 4 * num4 * num6;
                a1 = (-num4 + Math.Sqrt(delta)) / (2 * num4);
                a2 = (-num4 - Math.Sqrt(delta)) / (2 * num4);
                return delta;
                
            }
        }
    }
}